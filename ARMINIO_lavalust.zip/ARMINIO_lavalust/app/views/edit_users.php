<?php
defined('PREVENT_DIRECT_ACCESS') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Edit User</title>
    <link rel="shortcut icon" href="data:image/x-icon;," type="image/x-icon">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.6/css/dataTables.dataTables.css" />
   
    <style type="text/css">
       <style>
    html {
        margin: 20px;
    }
    body {
        font-size: 15px;
        font-family: 'Times New Roman', 'Georgia'; 
        color: #888;
        background: linear-gradient(to bottom right, #ff69b4, #add8e6, #8a2be2); 
        box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px, rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;
        min-height: 100vh; /* Ensures body takes full height */
        position: relative;
        padding-bottom: 60px; /* Add padding for the footer */
    }
    a {
        color: #003399;
        background-color: transparent;
        font-weight: normal;
    }
    .header {
        font-size: 30px;
        background-color: transparent; 
        color: #000000;
        padding: 15px;
        font-family: 'Georgia', serif; 
    }
    .main {
        color: #000000;
        background-color: none; 
        padding: 30px;
        font-family: 'Verdana', sans-serif;
    }
    .footer {
        font-family: 'Courier New', monospace;
        color: #000000;
        background-color: rgba(255, 255, 255, 0.8); 
        padding: 10px;
        text-align: center;
        border-top: solid 1px #d1c4e9;
        position: fixed; /* Keeps footer at the bottom */
        width: 100%; /* Makes footer full width */
        bottom: 0; /* Fixes the footer to the bottom of the viewport */
        left: 0;
    }
    .button-group {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
    }
    .btn {
        min-width: 100px;
    }
</style>
</head>
<body>
    <div class="header">Edit Users</div>
    <div class="main">
        <div class="container-fluid mt--6">
            <div class="row">
                <div class="col-sm-9 mx-auto">
                    <div class="card" style="box-shadow: 2px 5px 5px 3px #888888">
                        <div class="card-header m-0 font-weight-bold text-success" style="font-size:20px;border-bottom: 5px solid rgba(0, 0, 0, 0.125);">Edit Users</div>
                        <form action="<?= site_url('edit_users/' . $user['id']); ?>" method="post" enctype="multipart/form-data">
                            <div class="card-body">
                                <div class="form-group">
                                    <label class="control-label">Last Name</label>
                                    <textarea name="lastname" id="lastname" cols="30" rows="2" class="form-control"><?= $user['jaa_last_name']; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">First Name</label>
                                    <textarea name="firstname" id="firstname" cols="30" rows="2" class="form-control" required><?= $user['jaa_first_name']; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="" class="control-label">Email</label>
                                    <input type="email" class="form-control" name="email" required value="<?= $user['jaa_email']; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="category">Gender</label>
                                    <select class="form-control" id="Gender" name="Gender" required>
                                        <option value="Male" <?= $user['jaa_gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                                        <option value="Female" <?= $user['jaa_gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Address</label>
                                    <textarea name="address" id="address" cols="30" rows="2" class="form-control" required><?= $user['jaa_address']; ?></textarea>
                                </div>
                            </div>

                            <div class="card-footer">
                                <div class="button-group">
                                    <button class="btn btn-primary" type="submit" name="add_users">Save</button>
                                    <a class="btn btn-success" href="<?= site_url('home'); ?>">Back</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="footer">Page rendered with <?php echo $this->performance->memory_usage(); ?> in <strong><?php echo $this->performance->elapsed_time('lavalust'); ?></strong> seconds. <?php echo (config_item('ENVIRONMENT') === 'development') ?  'LavaLust Version <strong>' . config_item('VERSION') . '</strong>' : '' ?></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/2.1.6/js/dataTables.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#user_table').DataTable();
        });
    </script>
</body>
</html>
